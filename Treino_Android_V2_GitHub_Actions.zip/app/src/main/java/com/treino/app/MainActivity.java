package com.treino.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.Window;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); Window w=getWindow(); w.setStatusBarColor(Color.rgb(244,244,240)); w.getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); WebView v=new WebView(this); v.setBackgroundColor(Color.rgb(244,244,240)); v.setWebViewClient(new WebViewClient()); WebSettings s=v.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); v.loadUrl("file:///android_asset/index.html"); setContentView(v); }
 @Override public void onBackPressed(){ WebView v=(WebView)findViewById(android.R.id.content); if(v!=null && v.canGoBack()) v.goBack(); else super.onBackPressed(); }
}
