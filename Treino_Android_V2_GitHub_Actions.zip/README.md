# Treino — V2 Android

Aplicativo **Treino**, com interface mobile, plano de 4 semanas, cronômetro, progresso salvo no aparelho e funcionamento offline.

## Gerar o APK pelo celular usando GitHub Actions

1. Crie um repositório no GitHub chamado `Treino`.
2. Envie **o conteúdo desta pasta** para a raiz do repositório. A raiz precisa conter `app`, `build.gradle`, `settings.gradle` e `.github`.
3. Abra a aba **Actions** do repositório.
4. Se aparecer uma tela perguntando para habilitar Actions, permita.
5. Toque em **Gerar APK do Treino**.
6. Toque em **Run workflow** e confirme em **Run workflow**.
7. Aguarde a execução ficar verde (**Success**).
8. Abra a execução concluída e procure **Artifacts**.
9. Baixe **Treino-APK**. Dentro dele estará `Treino.apk`.
10. No Android, abra o APK e permita a instalação de aplicativos dessa fonte se o sistema pedir.

### Importante ao enviar pelo navegador do celular
Não envie a pasta `TreinoAndroid` como uma pasta dentro do repositório. Entre nela e envie os arquivos/pastas que estão dentro dela. O GitHub precisa enxergar `app/` diretamente na raiz.

## Requisitos da compilação

- GitHub Actions
- Java 17
- Gradle 8.11.1
- Android Gradle Plugin 8.7.3
- compileSdk 35
- minSdk 23

Não é necessário instalar Android Studio para gerar o APK pelo GitHub Actions.
